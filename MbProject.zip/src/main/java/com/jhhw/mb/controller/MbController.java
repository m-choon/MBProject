package com.jhhw.mb.controller;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.jhhw.mb.dto.BBSDto;
import com.jhhw.mb.service.MbService;

@Controller
public class MbController {
	
	@Autowired
	MbService mbService;

	
	@RequestMapping(value="/index.mb")
	public String home(Model model, HttpSession session, HttpServletRequest req){
		
		mbService.getleague(model);
		return "home";
	}
	
	@RequestMapping(value="/go.mb")
	public String marathongo(){
		return "marathongo";
	}
	
	@RequestMapping(value="/leaguelist.mb")
	public String leaguelist(Model model){
		mbService.getleague(model);

		return "leaguelist";
	}
		
		@RequestMapping(value="/bagiclist.mb")
	public String marathoninfo(int pageNum, Model model){
		mbService.list(pageNum,model);
		return "marathoninfo";
	}
	@RequestMapping(value="/readylist.mb")
	public String ready(int pageNum, Model model){
		mbService.readylist(pageNum, model);
		return "marathoninfo";
	}
	@RequestMapping(value="/traininglist.mb")
	public String training(int pageNum, Model model){
		mbService.traninglist(pageNum, model);
		return "marathoninfo";
	}
	@RequestMapping(value="/pluslist.mb")
	public String plus(int pageNum, Model model){
		mbService.pluslist(pageNum, model);
		return "marathoninfo";
	}
	@RequestMapping(value="/injurylist.mb")
	public String injury(int pageNum, Model model){
		mbService.injurylist(pageNum, model);
		return "marathoninfo";
	}
	@RequestMapping(value="/schoollist.mb")
	public String school(int pageNum, Model model){
		mbService.schoollist(pageNum, model);
		return "marathoninfo";
	}
	

	@RequestMapping(value="/bagiccontent.mb")
	public String bagiccontent(@RequestParam int pageNum,	//RequestParam�� �ڷᰪ�� �Է½�Ų�� (�̸��� ������ ��������) 
							BBSDto article, String articleNum, Model model){		
		article = mbService.bagiccontent(articleNum);
		String tb="bagic";
		model.addAttribute("tb", tb);
		mbService.bagicuphit(articleNum);
		model.addAttribute("article", article);
		model.addAttribute("pageNum", pageNum);
	return "content";	
	}
	@RequestMapping(value="/writeForm.mb")
	public String bagicwriteForm(HttpSession session){
		
	return "write";	
	}

	@RequestMapping(value="/write.mb")
	public String write(BBSDto article){	
		
		mbService.write(article);
		return "marathoninfo";	
	
	}
	@RequestMapping(value="/readycontent.mb")
	public String readycontent(@RequestParam int pageNum,	//RequestParam�� �ڷᰪ�� �Է½�Ų�� (�̸��� ������ ��������) 
							BBSDto article, String articleNum, Model model){		
		article = mbService.readycontent(articleNum);
		mbService.readyuphit(articleNum);
		String tb="ready";
		model.addAttribute("tb", tb);
		model.addAttribute("article", article);
		model.addAttribute("pageNum", pageNum);
	return "content";	
	}
	
	@RequestMapping(value="/trainingcontent.mb")
	public String trainingcontent(@RequestParam int pageNum,	//RequestParam�� �ڷᰪ�� �Է½�Ų�� (�̸��� ������ ��������) 
							BBSDto article, String articleNum, Model model){		
		article = mbService.trainingcontent(articleNum);
		mbService.traininguphit(articleNum);
		String tb="training";
		model.addAttribute("tb", tb);
		model.addAttribute("article", article);
		model.addAttribute("pageNum", pageNum);
	return "content";	
	}
	

	@RequestMapping(value="/pluscontent.mb")
	public String pluscontent(@RequestParam int pageNum,	//RequestParam�� �ڷᰪ�� �Է½�Ų�� (�̸��� ������ ��������) 
							BBSDto article, String articleNum, Model model){		
		article = mbService.pluscontent(articleNum);
		mbService.plusuphit(articleNum);
		String tb="plus";
		model.addAttribute("tb", tb);
		model.addAttribute("article", article);
		model.addAttribute("pageNum", pageNum);
	return "content";	
	}
	@RequestMapping(value="/injurycontent.mb")
	public String injurycontent(@RequestParam int pageNum,	//RequestParam�� �ڷᰪ�� �Է½�Ų�� (�̸��� ������ ��������) 
							BBSDto article, String articleNum, Model model){		
		article = mbService.injurycontent(articleNum);
		mbService.injuryuphit(articleNum);
		String tb="injurycontent";
		model.addAttribute("tb", tb);
		model.addAttribute("article", article);
		model.addAttribute("pageNum", pageNum);
	return "content";	
	}
	@RequestMapping(value="/schoolcontent.mb")
	public String content(@RequestParam int pageNum,	//RequestParam�� �ڷᰪ�� �Է½�Ų�� (�̸��� ������ ��������) 
							BBSDto article, String articleNum, Model model){		
		article = mbService.schoolcontent(articleNum);
		mbService.schooluphit(articleNum);
		String tb="school";
		model.addAttribute("tb", tb);
		model.addAttribute("article", article);
		model.addAttribute("pageNum", pageNum);
	return "content";	
	}
	/////////////////////////
	@RequestMapping(value="/info.mb")
	public String marathoninfo(){
		return "marathoninfo";
	}
	
	@RequestMapping(value="/my.mb")
	public String myinfo(Model model, String id, HttpSession session){
		id=(String) session.getAttribute("id");
		model = mbService.viewinfo(model, id, session);
		return "myinfo";
	}
	@RequestMapping(value="/together.mb")
	public String together(Model model, String id, String latitude, String longitude, HttpSession session){
		id = (String)session.getAttribute("id");
		model = mbService.myLocation(model, id, session);		
		model = mbService.togetherInfo(model, id, session);//다른놈들 정보		
		return "together";
	}
	@RequestMapping(value="/login.mb", method = RequestMethod.POST)
	public void login1(@RequestParam("testId") String testId, HttpSession session){
		System.out.println(testId);
		mbService.login(testId, session);
	}
	@RequestMapping(value="/and2web.mb")
	public void android2web(HttpServletRequest request, HashMap<String, String>infoMap){
		infoMap = new HashMap<String, String>();
		mbService.insertInfo(request, infoMap);

	}
	
	
}
