package com.jhhw.mb.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.jhhw.mb.dto.BBSDto;
import com.jhhw.mb.dto.LeagueDto;
import com.jhhw.mb.dto.UserDto;

public interface MbDao {
	public List<LeagueDto> getleague();

	public int getArticleCount();

	public List<BBSDto> getArticles(HashMap<String, Object> hm);

	public BBSDto bagiccontent(String articleNum);

	public void insertArticle(BBSDto article);

	public void bagicuphit(String articleNum);

	public int getreadyArticleCount();

	public List<BBSDto> getreadyArticles(HashMap<String, Object> hm);

	public int getplusArticleCount();

	public List<BBSDto> getplusArticles(HashMap<String, Object> hm);

	public int getinjuryArticleCount();

	public List<BBSDto> getinjuryArticles(HashMap<String, Object> hm);

	public int getschoolArticleCount();

	public List<BBSDto> getschoolArticles(HashMap<String, Object> hm);

	public int gettrainingArticleCount();

	public List<BBSDto> gettrainingArticles(HashMap<String, Object> hm);

	public BBSDto readycontent(String articleNum);

	public void readyuphit(String articleNum);

	public BBSDto trainingcontent(String articleNum);

	public void traininguphit(String articleNum);

	public BBSDto injurycontent(String articleNum);

	public void injuryuphit(String articleNum);

	public BBSDto schoolcontent(String articleNum);

	public void schooluphit(String articleNum);

	public BBSDto pluscontent(String articleNum);

	public void plusuphit(String articleNum);
	
	///////////////
	public void insertInfo(HashMap<String, String>infoMap);
	public String getInfoCount(String id);
	public ArrayList<UserDto> getuserInfo(String id);
	public ArrayList<UserDto> gettogetherInfo(String id);
	public ArrayList<UserDto> getMyLocation(String id);
	
	
}
