package com.jhhw.mb.dto;

public class BBSDto {
	private int articleNum;
	private String title;
	private String content;
	private String writeDate;
	private int hit;

	public int getArticleNum() {
		return articleNum;
	}
	public void setArticleNum(int articleNum) {
		this.articleNum = articleNum;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getHit() {
		return hit;
	}
	public void setHit(int hit) {
		this.hit = hit;
	}
	public String getWriteDate() {
		return writeDate;
	}
	public void setWriteDate(String writeDate) {
		this.writeDate = writeDate;
	}
	@Override
	public String toString() {
		return "BBSDto [articleNum=" + articleNum + ", title=" + title + ", content=" + content + ", writeDate=" + writeDate + ","
				+ " hit=" + hit	+ "]";
	}
	
	
}
