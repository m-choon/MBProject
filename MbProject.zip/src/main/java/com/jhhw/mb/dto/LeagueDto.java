package com.jhhw.mb.dto;

public class LeagueDto {
	String name;
	String leagueDate;
	String address;
	String leagueType;
	String sponsor;
	String startDate;
	String endDate;
	String homepage;
	
	@Override
	public String toString() {
		return "LeagueDto [name=" + name + ", leagueDate=" + leagueDate + ", address=" + address + ", leagueType="
				+ leagueType + ", sponsor=" + sponsor + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", homepage=" + homepage + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLeagueDate() {
		return leagueDate;
	}
	public void setLeagueDate(String leagueDate) {
		this.leagueDate = leagueDate;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getLeagueType() {
		return leagueType;
	}
	public void setLeagueType(String leagueType) {
		this.leagueType = leagueType;
	}
	public String getSponsor() {
		return sponsor;
	}
	public void setSponsor(String sponsor) {
		this.sponsor = sponsor;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getHomepage() {
		return homepage;
	}
	public void setHomepage(String homepage) {
		this.homepage = homepage;
	}
}
