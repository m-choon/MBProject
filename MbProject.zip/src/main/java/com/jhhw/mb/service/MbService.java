package com.jhhw.mb.service;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

import com.jhhw.mb.dto.BBSDto;

public interface MbService {

	public void getleague(Model model);

	public void list(int pageNum, Model model);

	public BBSDto bagiccontent(String articleNum);

	public void write(BBSDto article);

	public void bagicuphit(String articleNum);

	public void readylist(int pageNum, Model model);

	public void pluslist(int pageNum, Model model);

	public void injurylist(int pageNum, Model model);

	public void schoollist(int pageNum, Model model);

	public void traninglist(int pageNum, Model model);

	public BBSDto readycontent(String articleNum);

	public void readyuphit(String articleNum);

	public BBSDto trainingcontent(String articleNum);

	public void traininguphit(String articleNum);

	public BBSDto injurycontent(String articleNum);

	public void injuryuphit(String articleNum);

	public BBSDto schoolcontent(String articleNum);

	public void schooluphit(String articleNum);

	public BBSDto pluscontent(String articleNum);

	public void plusuphit(String articleNum);
/////
	public void insertInfo(HttpServletRequest request, HashMap<String, String>infoMap);
	public Model viewinfo(Model model, String id, HttpSession session);
	public void login(String id, HttpSession session);
	public Model togetherInfo(Model model, String id, HttpSession session);
	public Model myLocation(Model model, String id, HttpSession session);
}
