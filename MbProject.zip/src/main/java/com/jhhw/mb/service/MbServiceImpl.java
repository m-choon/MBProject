package com.jhhw.mb.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.jhhw.mb.common.Page;
import com.jhhw.mb.dao.MbDao;
import com.jhhw.mb.dto.BBSDto;
import com.jhhw.mb.dto.LeagueDto;
import com.jhhw.mb.dto.UserDto;

@Service
public class MbServiceImpl implements MbService {

	
	@Autowired
	MbDao mbDao;
	@Autowired
	Page page;
	
	HashMap<String, String> userMap, togetherMap;
	ArrayList<UserDto> infoList;

	@Override
	public void getleague(Model model) {
		List<LeagueDto> leagueList = null;
		leagueList = mbDao.getleague();
		model.addAttribute("leagueList", leagueList);
	}

	@Override
	public void list(int pageNum, Model model) {
		List<BBSDto> articleList=null;
		int totalCount=0;		
		int pageSize=10;//���������� ������ ���� ����
	    int pageBlock=10;//�� ���� ������ ������ ����  
	    String tb="bagic";
		String tbname="기초이론";
	    HashMap<String, Object> hm= new HashMap<String, Object>();
	    totalCount=mbDao.getArticleCount();
	    page.paging(pageNum, totalCount,pageSize, pageBlock,tb);
	    hm.put("startRow", page.getStartRow());
		hm.put("endRow", page.getEndRow());
		articleList=mbDao.getArticles(hm);
		model.addAttribute("tbname", tbname);
		model.addAttribute("tb", tb);
	    model.addAttribute("totalCount", totalCount);
	    model.addAttribute("pageCode", page.getSb().toString());
	    model.addAttribute("articleList", articleList);
	    model.addAttribute("pageNum", pageNum);
		
	}


	@Override
	public void readylist(int pageNum, Model model) {
		List<BBSDto> articleList=null;
		int totalCount=0;		
		int pageSize=10;//���������� ������ ���� ����
	    int pageBlock=10;//�� ���� ������ ������ ����  
		String tb="ready";
		String tbname="대회준비&회복";
	    HashMap<String, Object> hm= new HashMap<String, Object>();
	    totalCount=mbDao.getreadyArticleCount();
	    page.paging(pageNum, totalCount,pageSize, pageBlock,tb);
	    hm.put("startRow", page.getStartRow());
		hm.put("endRow", page.getEndRow());
		articleList=mbDao.getreadyArticles(hm);
		model.addAttribute("tbname", tbname);
		model.addAttribute("tb", tb);
	    model.addAttribute("totalCount", totalCount);
	    model.addAttribute("pageCode", page.getSb().toString());
	    model.addAttribute("articleList", articleList);
	    model.addAttribute("pageNum", pageNum);
		
	}

	@Override
	public void pluslist(int pageNum, Model model) {
		List<BBSDto> articleList=null;
		int totalCount=0;		
		int pageSize=10;//���������� ������ ���� ����
	    int pageBlock=10;//�� ���� ������ ������ ����  
	    HashMap<String, Object> hm= new HashMap<String, Object>();
	    totalCount=mbDao.getplusArticleCount();
		String tb="plus";
		String tbname="보강운동";

	    page.paging(pageNum, totalCount,pageSize, pageBlock,tb);
	    hm.put("startRow", page.getStartRow());
		hm.put("endRow", page.getEndRow());
		articleList=mbDao.getplusArticles(hm);
		model.addAttribute("tbname", tbname);

		model.addAttribute("tb", tb);
	    model.addAttribute("totalCount", totalCount);
	    model.addAttribute("pageCode", page.getSb().toString());
	    model.addAttribute("articleList", articleList);
	    model.addAttribute("pageNum", pageNum);
		
	}

	@Override
	public void injurylist(int pageNum, Model model) {
		List<BBSDto> articleList=null;
		int totalCount=0;		
		int pageSize=10;//���������� ������ ���� ����
	    int pageBlock=10;//�� ���� ������ ������ ����  
		String tb="injury";
		String tbname="마라톤부상";
	    HashMap<String, Object> hm= new HashMap<String, Object>();
	    totalCount=mbDao.getinjuryArticleCount();
	    page.paging(pageNum, totalCount,pageSize, pageBlock,tb);
	    hm.put("startRow", page.getStartRow());
		hm.put("endRow", page.getEndRow());
		articleList=mbDao.getinjuryArticles(hm);
		model.addAttribute("tbname", tbname);

		model.addAttribute("tb", tb);
	    model.addAttribute("totalCount", totalCount);
	    model.addAttribute("pageCode", page.getSb().toString());
	    model.addAttribute("articleList", articleList);
	    model.addAttribute("pageNum", pageNum);
		
	}

	@Override
	public void schoollist(int pageNum, Model model) {
		List<BBSDto> articleList=null;
		int totalCount=0;		
		int pageSize=10;//���������� ������ ���� ����
	    int pageBlock=10;//�� ���� ������ ������ ����  
		String tb="school";
		String tbname="마라톤교실";
	    HashMap<String, Object> hm= new HashMap<String, Object>();
	    totalCount=mbDao.getschoolArticleCount();
	    page.paging(pageNum, totalCount,pageSize, pageBlock,tb);
	    hm.put("startRow", page.getStartRow());
		hm.put("endRow", page.getEndRow());
		articleList=mbDao.getschoolArticles(hm);
		model.addAttribute("tbname", tbname);

		model.addAttribute("tb", tb);
	    model.addAttribute("totalCount", totalCount);
	    model.addAttribute("pageCode", page.getSb().toString());
	    model.addAttribute("articleList", articleList);
	    model.addAttribute("pageNum", pageNum);
		
	}

	@Override
	public void traninglist(int pageNum, Model model) {
		List<BBSDto> articleList=null;
		int totalCount=0;		
		int pageSize=10;//���������� ������ ���� ����
	    int pageBlock=10;//�� ���� ������ ������ ����  
		String tb="training";
		String tbname="마라톤훈련법";
	    HashMap<String, Object> hm= new HashMap<String, Object>();
	    totalCount=mbDao.gettrainingArticleCount();
	    page.paging(pageNum, totalCount,pageSize, pageBlock,tb);
	    hm.put("startRow", page.getStartRow());
		hm.put("endRow", page.getEndRow());
		articleList=mbDao.gettrainingArticles(hm);
		model.addAttribute("tbname", tbname);

		model.addAttribute("tb", tb);
	    model.addAttribute("totalCount", totalCount);
	    model.addAttribute("pageCode", page.getSb().toString());
	    model.addAttribute("articleList", articleList);
	    model.addAttribute("pageNum", pageNum);		
	}
	

	@Override
	public void write(BBSDto article) {
		mbDao.insertArticle(article);		
	}

	@Override
	public BBSDto bagiccontent(String articleNum) {
		return mbDao.bagiccontent(articleNum);
	}

	@Override
	public void bagicuphit(String articleNum) {
		mbDao.bagicuphit(articleNum);
		
	}

	@Override
	public BBSDto readycontent(String articleNum) {
		return mbDao.readycontent(articleNum);
	}

	@Override
	public void readyuphit(String articleNum) {
		mbDao.readyuphit(articleNum);
		
	}

	@Override
	public BBSDto trainingcontent(String articleNum) {
		return mbDao.trainingcontent(articleNum);
	}

	@Override
	public void traininguphit(String articleNum) {
		mbDao.traininguphit(articleNum);
		
	}

	@Override
	public BBSDto injurycontent(String articleNum) {
		return mbDao.injurycontent(articleNum);
	}

	@Override
	public void injuryuphit(String articleNum) {
		mbDao.injuryuphit(articleNum);
	}

	@Override
	public BBSDto schoolcontent(String articleNum) {
		return mbDao.schoolcontent(articleNum);
	}

	@Override
	public void schooluphit(String articleNum) {
		mbDao.schooluphit(articleNum);
	}

	@Override
	public BBSDto pluscontent(String articleNum) {
		return mbDao.pluscontent(articleNum);
	}

	@Override
	public void plusuphit(String articleNum) {
		mbDao.plusuphit(articleNum);
	}
	//////
	@Override
	public void login(String id, HttpSession session) {
		session.setAttribute("id", id);
	}
	@Override
	public void insertInfo(HttpServletRequest request, HashMap<String, String> infoMap) {
		infoMap.put("id", request.getParameter("id"));
		infoMap.put("email",  request.getParameter("email"));
		infoMap.put("name",  request.getParameter("name"));
		infoMap.put("gender",  request.getParameter("gender"));
		infoMap.put("time",  request.getParameter("time"));
//		infoMap.put("speed",  request.getParameter("speed"));
		String speed = request.getParameter("speed");
//		String.format("%.2f", Double.parseDouble(speed));
		infoMap.put("speed", String.format("%.2f", Double.parseDouble(speed)));
		infoMap.put("distance",  request.getParameter("distance"));
		infoMap.put("address",  request.getParameter("address"));
		infoMap.put("latitude", request.getParameter("latitude"));
		infoMap.put("longitude", request.getParameter("longitude"));
		long now = System.currentTimeMillis();
		Date date = new Date(now);
		SimpleDateFormat dataformat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		String clock = dataformat.format(date);
		infoMap.put("clock", clock);
		System.out.println(infoMap);
		mbDao.insertInfo(infoMap);
	}
	@Override
	public Model viewinfo(Model model, String id, HttpSession session) {
		infoList = mbDao.getuserInfo(id);
		String infoCount=null;
		System.out.println(id);
		infoCount=mbDao.getInfoCount(id);
		System.out.println(infoCount);
		model.addAttribute("infoCount", infoCount);
		model.addAttribute("infoList", infoList);
		session.setAttribute("id", id);
		model.addAttribute("id", id);
		return model;
	}
	@Override
	public Model togetherInfo(Model model, String id, HttpSession session) {
		infoList = mbDao.gettogetherInfo(id);
		int i = infoList.size();
		for(int j=0; j<i; j++){
			Double latitude1 = Double.parseDouble(infoList.get(j).getLatitude());
			Double longitude1 = Double.parseDouble(infoList.get(j).getLongitude());
			Double latitude2 = Double.parseDouble((String)session.getAttribute("latitude"));
			Double longitude2 = Double.parseDouble((String)session.getAttribute("longitude"));			
			String howLong = String.valueOf(distance(latitude1, longitude1, latitude2, longitude2));
			infoList.get(j).setHowLong(howLong);
		}
		System.out.println(infoList);
		model.addAttribute("infoList", infoList);

		return model;
	}
	@Override
	public Model myLocation(Model model, String id, HttpSession session) {
		int infoCount=Integer.parseInt(mbDao.getInfoCount(id));
		if(infoCount!=0){
		infoList = mbDao.getMyLocation(id);
		String latitude = infoList.get(0).getLatitude();
		
		String longitude = infoList.get(0).getLongitude();
		session.setAttribute("latitude", latitude);
		session.setAttribute("longitude", longitude);
		model.addAttribute("infoList", infoList);
		}else
			session.setAttribute("infoCount", infoCount);
			
		
		return model;
	}
	public static double distance(double latitude1, double longitude1, double latitude2, double longitude2) {
    	double theta = longitude1 - longitude2;
        double dist = Math.sin(deg2rad(latitude1)) * Math.sin(deg2rad(latitude2)) + Math.cos(deg2rad(latitude1)) * Math.cos(deg2rad(latitude2)) * Math.cos(deg2rad(theta));

        dist = Math.acos(dist);
        dist = rad2deg(dist);
        dist = dist * 60 * 1.1515;
        dist = dist * 1609.344;

        return (dist);
    }
    private static double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }
    private static double rad2deg(double rad) {
        return (rad * 180 / Math.PI);
    }
	
}
