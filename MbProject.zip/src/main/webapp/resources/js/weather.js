function callSKPlanetWeather(lat, lon) {
		var request = new XMLHttpRequest();
		var url = 'http://apis.skplanetx.com/weather/current/hourly';
		var appKey = '16f773be-67d5-328f-8765-3781770f49f4';
		var queryParams = '?version=' + '1';
		queryParams += '&lat=' + lat; // 위도
		queryParams += '&lon=' + lon; // 경도
		queryParams += '&appKey=' + appKey; // API 키 (SK플래닛 개발자센터에서 발급)

		request.open('GET', url + queryParams, true);
		request.onload = function() {
			if (request.status == 200) {
				var response = JSON.parse(request.responseText);
				var weather = response.weather.hourly[0];
				var sky = weather.sky.name;
				var temp = weather.temperature.tc;
				var tempmax = weather.temperature.tmax;
				var tempmin = weather.temperature.tmin;
				var wspd = weather.wind.wspd;
				var rain = weather.precipitation.sinceOntime;
				if (sky === "맑음") {
					$('.sky_info').attr("src", "resources/img/맑음.png");
				} else if (sky === "구름조금") {
					$('.sky_info').attr("src", "resources/img/구름조금.png");
				} else if (sky === "구름많고 비" || sky == "흐리고 비" || sky == "뇌우, 비") {
					$('.sky_info').attr("src", "resources/img/비.png");
				} else if (sky == "구름많음" || sky == "흐림") {
					$('.sky_info').attr("src", "resources/img/흐림.png");
				} else if (sky == "흐리고 눈" || sky == "뇌우, 눈") {
					$('.sky_info').attr("src", "resources/img/눈.png");
				}
				$('.sky_info_text').html(sky);
				$('.temp').html(temp);
				$('.temp_max').html(tempmax + "/" + tempmin);
				$('.wind').html(wspd + "m/s");
				$('.rain').html(rain + "mm");

			}
		};
		request.send(null);
	}
	function callSKPlanetDust(lat, lon) {
		var request = new XMLHttpRequest();
		var url = 'http://apis.skplanetx.com/weather/dust';
		var appKey = '16f773be-67d5-328f-8765-3781770f49f4';
		var queryParams = '?version=' + '1';
		queryParams += '&lat=' + lat; // 위도
		queryParams += '&lon=' + lon; // 경도
		queryParams += '&appKey=' + appKey; // API 키 (SK플래닛 개발자센터에서 발급)

		request.open('GET', url + queryParams, true);
		request.onload = function() {
			if (request.status == 200) {
				var response = JSON.parse(request.responseText);
				var dust = response.weather.dust[0];
				var dustvalue = dust.pm10.value;
				var dustgrade = dust.pm10.grade;
				$('.dustvalue').html(dustvalue);
				$('.dustgrade').html(dustgrade);
			}
		};
		request.send(null);
	}
	function callSKPlanetUvindex(lat, lon) {
		var request = new XMLHttpRequest();
		var url = 'http://apis.skplanetx.com/weather/windex/uvindex';
		var appKey = '16f773be-67d5-328f-8765-3781770f49f4';
		var queryParams = '?version=' + '1';
		queryParams += '&lat=' + lat; // 위도
		queryParams += '&lon=' + lon; // 경도
		queryParams += '&appKey=' + appKey; // API 키 (SK플래닛 개발자센터에서 발급)
		request.open('GET', url + queryParams, true);
		request.onload = function() {
			if (request.status == 200) {
				var response = JSON.parse(request.responseText);
				var wIndex = response.weather.wIndex.uvindex[0];
				var uvindex = wIndex.day00.index;
				if (uvindex == '') {
					uvindex = 0;
				}
				$('.uvindex').html(uvindex);

			}
		};
		request.send(null);
	}
	function callSKPlanetThindex(lat, lon) {
		var request = new XMLHttpRequest();
		var url = 'http://apis.skplanetx.com/weather/windex/thindex';
		var appKey = '16f773be-67d5-328f-8765-3781770f49f4';
		var queryParams = '?version=' + '1';
		queryParams += '&lat=' + lat; // 위도
		queryParams += '&lon=' + lon; // 경도
		queryParams += '&appKey=' + appKey; // API 키 (SK플래닛 개발자센터에서 발급)
		request.open('GET', url + queryParams, true);
		request.onload = function() {
			if (request.status == 200) {
				var response = JSON.parse(request.responseText);
				var wIndex = response.weather.wIndex.thIndex[0];
				var thindex = wIndex.current.index;
				$('.thindex').html(thindex);
				
			}
		};
		request.send(null);
	}
	